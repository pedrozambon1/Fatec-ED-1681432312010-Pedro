package n3ed;

import javax.swing.JOptionPane;

public class SaidaDados {

    static String saidaDadosEmOrdem(No no, String result) {
        if (no != null) {
            result = "" + saidaDadosEmOrdem(no.esquerda, result) + " " + no.getVal() + " "
                    + saidaDadosEmOrdem(no.direita, result);
            return result;
        }
        return "";
    }

    static void selectOrder(No no) {
        String valNo1 = JOptionPane.showInputDialog(null, "Imprimir árvore em ordem: " + "\n1: para exibir em ordem"
                + "\n0: Para sair");
        int val = 0;
        try {
            val = Integer.parseInt(valNo1);
        } catch (Exception e) {
            selectOrder(no);
        }
        if (val == 1) {
            String result = saidaDadosEmOrdem(no, "");
            JOptionPane.showMessageDialog(null, "Resultado: " + result);
        }
        if (val == 0)
            return;
        else
            selectOrder(no);
    }
}
