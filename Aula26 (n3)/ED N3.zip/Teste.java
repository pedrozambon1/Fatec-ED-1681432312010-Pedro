package n3ed;

public class Teste {

    public static void main(String[] args) {
        new EntradaDados();
        new SaidaDados();

        No no = EntradaDados.criarNo();
        SaidaDados.selectOrder(no);
    }
}